Sungjoo Cha(A00811990) lsj937@gmail.com
Sam Collins(A00987689) samcollins427@gmail.com
Set D

What we have completed:
-Transparent banner
-Image as background on all our 15 pages
-Main font style is Arial and secondary font style is Sans-serif
-Buttons on all our pages to navigate to homepage, 12 Signs, and Contact us page from any of the pages
-Information on our index.html is from: https://www.travelchinaguide.com/intro/social_customs/zodiac/
-Information on our pages of each sign is from: https://www.buildingbeautifulsouls.com/zodiac-signs/chinese-zodiac-signs-meanings/\
-Name, Email, comment boxes, and hidden textboxes on the contact page
-footer at the bottom of the page with all the required information(email addresses obfuscated)

The whole assignment was a major challenge. As challenging as it was, we were able to learn various skills of using XHTML by
continuing trial and error. 

